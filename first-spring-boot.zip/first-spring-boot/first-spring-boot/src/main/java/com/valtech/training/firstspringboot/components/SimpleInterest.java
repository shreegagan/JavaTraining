package com.valtech.training.firstspringboot.components;

public interface SimpleInterest {
	double ComputeInterest(int prin,int roi,int time);
}
