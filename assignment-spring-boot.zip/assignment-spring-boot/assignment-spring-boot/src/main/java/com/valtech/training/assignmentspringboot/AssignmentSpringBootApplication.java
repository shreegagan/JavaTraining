package com.valtech.training.assignmentspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentSpringBootApplication.class, args);
	}

}
